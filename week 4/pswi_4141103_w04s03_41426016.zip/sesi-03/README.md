<!-- Nama :Pelita Rut Gratia Tambunan -->
<!-- NIM : 41426016 -->
<!-- Program Studi : D4-Teknologi Rekayasa Perangkat Lunak -->

1. body, header, dan main di halaman di batasi lebar maksimalnya hingga 50rem dan berada di tengah layar secara horizontal.
2. Menggunakan jenis huruf arial-san serif pada halaman web.
3. Formulir disusun secara vertikal dengan jarak antar elemen sebesar 1.2rem. Label bertuliskan bold dan bewarna abu abu tua.
4. input[type="submit"] menggunakan warna latar belakang putih.

Tujuan dari praktikum ini, yang saya dapat yaitu saya menjadi tahu mempercantik sebuah web yang akan dibuat,sehingga customer tidak bosan melihat web yang saya buat. Saya juga menjadi lumayan paham bahwa menyesuaikan tampilan dan memahami  cara mengatur layout halaman web agar rapi dan terstruktur pada sebuah web cukup penting.

Saya menggunakan AI untuk membantu dalam mempercantik css. Dan menggunakan AI untuk mencari tahu apa fungsi dari border-radius. Dan yang saya dapat adalah border radius digunakan untuk membuat sudut pada elemen box menjadi melengkung sesuai ukuran yang kita mau.