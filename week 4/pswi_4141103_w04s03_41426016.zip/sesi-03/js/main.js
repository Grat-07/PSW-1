const greetingButton =
 document.querySelector('#greeting-button');
greetingButton.addEventListener('click', () => {
 alert('Selamat belajar di INSTITUT TEKNOLOOGI DEL!');
});

console.log('main.js berhasil dijalankan');

document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        alert("Pendaftaran berhasil!");
    });
});
