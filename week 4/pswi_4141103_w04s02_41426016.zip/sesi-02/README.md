/*
Nama : Pelita Rut Gratia Tambunan
NIM : 41426016
Prodi : D4 TEKNOLOGI REKAYASA PERANGKAT LUNAK
\*

1. Persiapan stylesheet : memasukkan <link rel="stylesheet" href="style.css"> ke dalam index.html agar style.css dapat terhubung ke index.html.
2. Selector and class : selector dan class digunakan untuk mengidentifikasi elemen tujuan agar aturan css diterapkan pada tempat yang tepat.
   prediksi: warna teks petunjuk berubah.
   hasil akhir: form.card memiliki jarak ruang dalam kotak sebesar 1rem dan warna latar belakang putih.
3. Konflik Specificity : mengatur warna teks berdasarkan aturan spesifisitas.
   prediksi: teks paragraf petunjuk akan berwarna ungu.
   hasil akhir: teks paragraf petunjuk akan berwarna ungu ,sedangkan aturan warna orange akan diabaikan oleh browser.
4. Ukuran kotak : mengatur bentuk, ukuran, dan jarak luar-dalam dari kotak yang memiliki class="card".
   prediksi: lebar kotak awalnya adalah 276px tanpa box sizing:border box
   hasil akhir: lebar kotak berubah menjadi 240px setelah properti box sizing:border box ditambahkan

   Hasil yang didaftarkan: file:///D:/Semester%201/Pengembangan%20Situs%20Web%201/Week%204/pswi-week-4/sesi-02/index.html?nama=Giska+Tarigan&kode=414230&phone=0812435600&email=giska.tarigan%40gmail.com&tickets=3&prodi=trpl&mode=luring&topik=html&catatan=giska.tarigan#

Saya menggunakan AI untuk membantu saya dalam melakukan debugging dan mendeteksi error dan membantu memahami lebih dalam tentang perbedaan .card dan .notice. Dimana yang saya dapat bahwa .card dan .notice adalah class selector. Tanda . diawal untuk menandakan bahwa keduanya adalah nama kelas untuk mengelompokkan elemen. ".card" adalah komponen visual berbentuk kartu. Sedangkan ".notice" untuk menandai elemen teks sebagai pesan pemberitahuan atau petunjuk.
