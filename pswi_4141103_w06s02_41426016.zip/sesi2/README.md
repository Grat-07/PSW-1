<!-- Nama : Pelita Rut Gratia Tambunan -->
<!-- NIM : 41426016 -->
<!-- Prodi : D4-Teknologi Rekayasa Perangkat Lunak -->

Kasus                      |         Yang Terjadi
320px                      |         pada lebar 320px, tampilan tetap rapi dan tidak mengalami perubahan layout maupun elemen yang berlebihan.
Sekitar breakpoint         |         pada percobaan 767px,768px,769px, tampilan web mengikuti sesuai kondisi media query
Keyboard                   |         dapat masuk ke bagian beranda 
 
 Zoom 200% : ketika web di zoom 200%, teks, gambar, dan kartu tampak besar dan gambar tetap menyesuaikan kartu karena max-width: 100%

Saya menggunakan AI untuk membantu saya dalam mempercantik dan merapikan css saya.
Saya juga menggunakan AI untuk belajar dan yang saya dapat :
1. Media query itu digunakan untuk merespon web. Media query ini berfungsi mendeteksi ukuran layar atau viewport,karena layar penggunaan antara Smartphone dan Laptop itu berbeda.
2. min-width: 48rem itu adalah ukuran yang dianggap batasan antara layar batas antara layar ponsel. Menggunakan rem dan bukan px untuk membuat breakpoint ikut menyesuaikan jika pengguna mengubah ukuran font di browser.
3. max-width: 100% adalah ukuran yang menjaga keterbacaan sebuah web.
4. Breakpoint itu titik ukuran lebar layar di mana tampilan website berubah menyesuaikan perangkat dan ini sangat dibutuhkan karena wwebsite yang dibuat bisa dibuka di banyak perangkat dengan lebar berbeda seperti smartphone, tablet, laptop, dan monitor besar.
