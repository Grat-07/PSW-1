Validator index.html : Tidak ada error sama sekali
Validator kegiatan.html : warning, pada baris 28 dan kolom 5, ke baris 8 kolom 34, jika diubah 0 maka garis tabel nya akan hilang
Validator kontak : Tidak ada error sama sekali

Sumber gambar 
1. pribadi
2. https://share.google/4viXeEBtVXHd7agYw