<!-- Nama : Pelita Rut Gratia Tambunan -->
<!-- NIM : 41426016 -->
<!-- Prodi : D4- TEKNOLOGI REKAYASA   PERANGKAT LUNAK -->

Saya menggunakan transition agar ketika mouse masuk, warna dan ukuran kartu langsung loncat, dengan peprubahan meluncur pelan.

Saat cache dimatikan pada network, browser tetap bisa memilih kandidat besar yang artinya browser tetap bisa mengambil file 640w di layar kecil.

perbedaan foto yang menggunakan srcset dengan yang tidak yaitu : foto yang menggunakan srcset berguna agar browser memilih ukuran gambar yang paling cocok untuk perangkat pengungjung, yang artinya jika pengunjung menggunakan HP berlayar kecil akan dikirimi yang kecil, sedangkan jika pengunjung menggunakan layar besar seperti Laptop, gambar yang ditampilkan punn yang besar.

Menggunakan  { max-width: 100%; height: auto; } agar gambar menyesuaikan  lebar tempatnya berada dan tidak emlebihi kapasitas layar, dimana max-width: 100% lebar gambar tidak melebihi lebar wadahnya dan height: auto yang artinya tinggi gambar dihitung otomatis mengikuti lebarnya, sehingga perbandingan lebar dan tinggi tetap sama.