<!-- Nama : Pelita Rut Gratia Tambunan -->
<!-- NIM :41426016 -->
<!-- Prodi : D4-TEKNOLOGI REKAYASA PERANGKAT LUNAK -->

LATIHAN MANDIRI
1. Ketika di zoom 200%, kotak tetap menyesuaikan ukuran dan tetap rapi
2. Ketika pada .card bagian border diubah dari 1px menjadi 320px yang terjadi yaitu kartu mengecil dan memperlihatkan background pada web
3. Ketika 1 card dengan menggunakan border 320px card tetap terbaca, namun menjadi kecil
4. Ketika 5 card dengan menggunakan border 320px card tetap terbaca, namun menjadi kecil dan tidak dapat langsung dibaca secara bersama-sama antara card lain

Saya menggunakan AI untuk menambahkan kalimat di article saya, yaitu "Melalui proses latihan yang sistematis—mulai dari menyusun dokumen dasar, memahami konsep aliran normal (normal flow), hingga menguji batasan layar dengan berbagai skenario data—seorang pengembang web dapat melatih ketelitian logika dan pemecahan masalah teknis, sehingga mampu menghasilkan kode yang bersih, mudah diakses oleh semua kalangan pengguna, serta mematuhi standar industri global yang berlaku."