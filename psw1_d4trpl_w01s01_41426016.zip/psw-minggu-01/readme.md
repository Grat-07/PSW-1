Laporan Praktikum Instalasi Tools dan Halaman Web Pertama (Pengembangan Situs Web)

Nama: Pelita Rut Gratia Tambunan
NIM: 41426016
Prodi: DIV Teknologi Rekayasa Perangkat Lunak

Refleksi dari fungsi HTML, CSS, JAVASCRIPT termasuk GIT

1. GIT
GIT adalah program yang kita jalankan melalui terminal. GIT berguna untuk mengatur dan mencatat versi perubahan kode. Kita juuga dapat berkolaborasi online dengan teman melalui GITHUB.

2. HTML
HTML atau Hypertext markup language adalah sebuah bahasa markup yang digunakan untuk membuat halaman web bukan bahasa pemograman. HTML memiliki peran yaitu sebagai struktur halaman dan menyajikan konten. Analoginya yaitu HTML sebagai seseorang yang memiliki kepala,tangan,kaki.

3. CSS
CSS atau Cascading Style Sheet berguna untuk mempercantik sebuah web seperti memberi warna,gambar,animasi. Analoginya yaitu seseorang yang dikenakan baju,celana.

4. JAVASCRIPT
JAVASCRIPT membuat sebuah website menjadi interaktif. Analoginya yaitu merupakan otak dari seseorang itu sendiri sehingga bisa berjalan,bergaya. 