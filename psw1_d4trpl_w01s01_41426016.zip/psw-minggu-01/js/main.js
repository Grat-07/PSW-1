const greetingButton =
 document.querySelector('#greeting-button');
greetingButton.addEventListener('click', () => {
 alert('Selamat belajar di INSTITUT TEKNOLOOGI DEL!');
});
console.log('main.js berhasil dijalankan');