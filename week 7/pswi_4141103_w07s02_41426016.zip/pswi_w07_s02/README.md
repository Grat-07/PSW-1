<!-- Nama : Pelita Rut Gratia Tambunan -->
<!-- NIM : 41426016 -->
<!-- Prodi : DD4-TEKNOLOGI REKAYASA PERANGKAT LUNAK -->

1. Mengganti  pola navigasi yang dari week 3 menjadi :
<nav aria-label="Navigasi utama">
<a href="index.html">Berada</a>
<a href="kegiatan.html">Kegiatan</a>
<a href="daftar.html">Daftar</a>
</nav>
Dimana dengan mengguunakan kode ini, ketika ingin menklik tujuan halaman dari sebuah web dapat masuk sesuai halaman yang di klik.

2. Halaman : index.html
   Kasus : layar  320px
   Harapan : Tidak ada yang scroll ke bawah, menu dan gambar tidak terpotong
   Hasil nyata : Gambar  yang terpisah dari navigasi
   Status : Isi telah diuji

   Kasus : layar 1200px
   Harapan : Tata letak rapi dan konten tidak melebar berlebihan
   Hasil nyata : Perlu memeriksa main yang di gunakan punya batas lebar yaitu (max-width)
   Status : isi telah di uji

    Kasus : zoom 200%
    Harapan : teks tetap tebaca, tidak saling menumpuk
    Hasil nyata : Ukuran font memakai rem atau % bukan px
    Status : Isi telah diuji

3. Halaman : kegiatan.html
   Kasus : Keyboard
   Harapan : Halaman yang di klik dapat dijangkau dan terlihat fokus
   Hasil nyata : Semua elemen memakai <a> dapat dijangkau dan difokuskan
   Status : Isi setelah diuji

4. Halaman : daftar.html
   Kasus : Menu Navigasi
   Harapan : Teks dan bentuk sama dengan halaman lain
   Hasil nyata : Tulisan "daftar" huruf kecil dan ada garis pemisah 
   Status,  Gagal dan perlu di perbaiki

   Saya menggunakan AI untuk membantu saya dalam membuat sebuah css yang rapi serta bagus. AI juga membantu saya dalam mengeksplor apa pengertian serta fungsi dari css yang saya gunakan.
