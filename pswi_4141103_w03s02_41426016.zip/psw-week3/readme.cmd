/*
Nama : Pelita Rut Gratia Tambunan
NIM : 41426016
Prodi : Teknologi Rekayasa Perangkat Lunak (TRPL 1)
\*

id digunakan untuk memberikan identitas unik pada suatu elemen HTML.
for digunakan pada elemen <label> untuk menghubungkan label tersebut dengan elemen <input>.
type digunakan untuk menentukan jenis inpit yang akan ditampilkan pada halaman web dan bagaimana browser menjalankannya.
text digunakan untuk memasukkan teks.
email untuk memasukkan alamat email.
tel untuk memasukkan nomor telepon.
number untuk memasukkan angka.
radio untuk memilih salah satu pilihan dari pilihan yang ditentukan.
checkbox dapat memilih lebih dari 1 pilihan.

Tujuan saya mengerjakan modul week 3 sesi 2 yaitu agar saya mengetahui cara membuat form dalam bentuk website. Dan saya menjadi tahu penggunaan 
seperti checkbox, radio,input,label, id,value dan lain lain.

Hasil Uji : file:///D:/Semester%201/Pengembangan%20Situs%20Web%201/Week%203/psw-week3/get?nama=Giska+Tarigan&phone=0812807890&tickets=2&email=giska.tarigan%40gmail.com&prodi=trpl&mode=luring&topik=html&topik=aksesibilitas&catatan=saya+mengikuti

Saya menggunakan AI untuk mengetahui letak error saya sehingga saya memahami dan mengerti apa yang membuat program saya error. Sperti di code saya bagian checkbox, saya tidak tahu letak error nya 
sehingga saya meminta bantuan dari AI untuk memberitahu letak error serta memberikan penjelasan sehingga saya mengerti kenapa bisa error.
